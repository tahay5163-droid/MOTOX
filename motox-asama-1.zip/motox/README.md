# MOTOX

React Native + Expo + TypeScript + Expo Router + Supabase.

## Mimari

```
app/                      Expo Router (dosya tabanlı yönlendirme)
  _layout.tsx             Font yükleme, AuthProvider, oturum koruması (AuthGate)
  index.tsx               Açılış animasyonu -> oturuma göre yönlendirme
  (auth)/                 login, register, forgot-password
  (tabs)/                 index (Ana Sayfa), garage, ride, community, profile
src/
  theme/tokens.ts         Renk, boşluk, radius, tipografi (tek kaynak)
  lib/                    supabase istemcisi, zod doğrulama, hata mesajları
  providers/              AuthProvider (oturum, giriş, kayıt, çıkış, şifre sıfırlama)
  components/ui/          Text, Button, Input, GlassCard, Skeleton, EmptyState, Screen
  components/             TabBar (animasyonlu), Wordmark
supabase/schema.sql       Tablolar, tetikleyiciler, RLS, storage politikaları
```

Kurallar: veri erişimi her zaman Supabase + RLS üzerinden; her form zod ile doğrulanır;
her ekran `Screen` ile güvenli alan/klavye/kaydırma kazanır; renk ve font sadece `tokens.ts`'ten gelir.

## Kurulum

```bash
npx create-expo-app@latest motox --template blank-typescript
cd motox
# Şablondaki App.tsx ve index.ts dosyalarını sil; package.json içinde "main": "expo-router/entry" yap.
# Bu klasördeki app/, src/, supabase/, app.json, tsconfig.json, .env.example dosyalarını üzerine kopyala.

npx expo install expo-router expo-linking expo-constants expo-status-bar expo-splash-screen expo-font \
  react-native-safe-area-context react-native-screens react-native-gesture-handler \
  react-native-reanimated react-native-worklets expo-blur expo-linear-gradient \
  @expo-google-fonts/barlow @expo-google-fonts/barlow-condensed \
  lucide-react-native react-native-svg \
  @supabase/supabase-js @react-native-async-storage/async-storage react-native-url-polyfill \
  expo-notifications expo-location expo-image-picker
npm install zod

cp .env.example .env      # Supabase URL ve anon anahtarını doldur
npx expo start            # i = iOS simülatörü, a = Android emülatörü, ya da Expo Go ile QR
```

Supabase tarafı: yeni proje aç -> SQL Editor'de `supabase/schema.sql` çalıştır ->
Authentication > URL Configuration'a `motox://` yönlendirmesini ekle.
E-posta doğrulaması açıksa kayıt sonrası doğrulama ekranı görünür.

## Durum

| Aşama | Durum |
|---|---|
| Mimari, dosya yapısı, tasarım sistemi | Hazır |
| Açılış ekranı, auth (kayıt/giriş/şifremi unuttum/oturum) | Hazır, test edilmedi |
| Alt menü, Ana Sayfa iskeleti (profil + garaj sayısı) | Hazır, test edilmedi |
| Veritabanı şeması + RLS + storage | Hazır, Supabase'de çalıştırılmadı |
| Dijital garaj, bakım, yakıt, sürüş, topluluk, pazar, profil/ayarlar, bildirimler | Sıradaki aşamalar |
| Uygulama içi şifre sıfırlama ekranı (derin bağlantı) | Sıradaki: şu an e-posta bağlantısı gönderilir |
