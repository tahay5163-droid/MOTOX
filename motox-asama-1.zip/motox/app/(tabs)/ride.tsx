import { Route } from 'lucide-react-native';
import { colors } from '@/theme/tokens';
import { Screen } from '@/components/ui/Screen';
import { Text } from '@/components/ui/Text';
import { EmptyState } from '@/components/ui/EmptyState';

export default function RideScreen() {
  return (
    <Screen tabBar>
      <Text variant="title">Sürüş</Text>
      <EmptyState icon={<Route size={32} color={colors.accent} />} title="Bu bölüm yolda" message="Sürüş günlüğü ve harita rotaları sıradaki aşamalarda geliyor." />
    </Screen>
  );
}
