import { Warehouse } from 'lucide-react-native';
import { colors } from '@/theme/tokens';
import { Screen } from '@/components/ui/Screen';
import { Text } from '@/components/ui/Text';
import { EmptyState } from '@/components/ui/EmptyState';

export default function GarageScreen() {
  return (
    <Screen tabBar>
      <Text variant="title">Garaj</Text>
      <EmptyState icon={<Warehouse size={32} color={colors.accent} />} title="Bu bölüm yolda" message="Motosikletlerini ekleyip düzenleyeceğin dijital garaj sıradaki aşamada geliyor." />
    </Screen>
  );
}
