import { Users } from 'lucide-react-native';
import { colors } from '@/theme/tokens';
import { Screen } from '@/components/ui/Screen';
import { Text } from '@/components/ui/Text';
import { EmptyState } from '@/components/ui/EmptyState';

export default function CommunityScreen() {
  return (
    <Screen tabBar>
      <Text variant="title">Topluluk</Text>
      <EmptyState icon={<Users size={32} color={colors.accent} />} title="Bu bölüm yolda" message="Gönderi akışı, beğeni ve yorumlar sıradaki aşamalarda geliyor." />
    </Screen>
  );
}
