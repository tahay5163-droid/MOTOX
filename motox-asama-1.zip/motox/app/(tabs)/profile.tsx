import { useState } from 'react';
import { Alert, View } from 'react-native';
import { LogOut } from 'lucide-react-native';
import { useAuth } from '@/providers/AuthProvider';
import { friendlyError } from '@/lib/errors';
import { Screen } from '@/components/ui/Screen';
import { Text } from '@/components/ui/Text';
import { GlassCard } from '@/components/ui/GlassCard';
import { Button } from '@/components/ui/Button';

export default function ProfileScreen() {
  const { user, signOut } = useAuth();
  const [busy, setBusy] = useState(false);

  async function logout() {
    setBusy(true);
    try {
      await signOut(); // AuthGate giriş ekranına yönlendirir
    } catch (e) {
      Alert.alert('Çıkış yapılamadı', friendlyError(e));
      setBusy(false);
    }
  }

  return (
    <Screen tabBar>
      <Text variant="title">Profil</Text>
      <GlassCard>
        <Text variant="caption" muted>Giriş yapılan hesap</Text>
        <Text variant="bodyStrong">{user?.email}</Text>
      </GlassCard>
      <View style={{ gap: 10 }}>
        <Text muted>Profil düzenleme, fotoğraf, ayarlar ve hesap silme profil aşamasında eklenecek.</Text>
        <Button label="ÇIKIŞ YAP" variant="secondary" icon={<LogOut size={18} color="#fff" />} onPress={logout} loading={busy} />
      </View>
    </Screen>
  );
}
