import { useCallback, useState } from 'react';
import { Image, View } from 'react-native';
import { useFocusEffect, useRouter } from 'expo-router';
import { Warehouse, TriangleAlert } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { friendlyError } from '@/lib/errors';
import { useAuth } from '@/providers/AuthProvider';
import { colors, fonts, radius } from '@/theme/tokens';
import { Screen } from '@/components/ui/Screen';
import { Text } from '@/components/ui/Text';
import { GlassCard } from '@/components/ui/GlassCard';
import { Skeleton } from '@/components/ui/Skeleton';
import { EmptyState } from '@/components/ui/EmptyState';
import { Button } from '@/components/ui/Button';

type State =
  | { status: 'loading' }
  | { status: 'error'; message: string }
  | { status: 'ready'; username: string; avatarUrl: string | null; bikeCount: number };

function greeting() {
  const h = new Date().getHours();
  if (h < 6) return 'İyi geceler';
  if (h < 12) return 'Günaydın';
  if (h < 18) return 'İyi günler';
  return 'İyi akşamlar';
}

export default function Home() {
  const { user } = useAuth();
  const router = useRouter();
  const [state, setState] = useState<State>({ status: 'loading' });

  const load = useCallback(async () => {
    if (!user) return;
    setState({ status: 'loading' });
    try {
      const [profile, bikes] = await Promise.all([
        supabase.from('profiles').select('username, avatar_url').eq('id', user.id).single(),
        supabase.from('motorcycles').select('id', { count: 'exact', head: true }),
      ]);
      if (profile.error) throw profile.error;
      if (bikes.error) throw bikes.error;
      setState({
        status: 'ready',
        username: profile.data.username,
        avatarUrl: profile.data.avatar_url,
        bikeCount: bikes.count ?? 0,
      });
    } catch (e) {
      setState({ status: 'error', message: friendlyError(e) });
    }
  }, [user]);

  useFocusEffect(useCallback(() => { load(); }, [load]));

  return (
    <Screen tabBar>
      {state.status === 'loading' && (
        <>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
            <Skeleton width={52} height={52} style={{ borderRadius: 26 }} />
            <View style={{ gap: 8 }}><Skeleton width={120} height={14} /><Skeleton width={180} height={22} /></View>
          </View>
          <Skeleton height={190} style={{ borderRadius: radius.lg }} />
        </>
      )}

      {state.status === 'error' && (
        <EmptyState
          icon={<TriangleAlert size={30} color={colors.accent} />}
          title="Veriler yüklenemedi"
          message={state.message}
          actionLabel="Tekrar dene"
          onAction={load}
        />
      )}

      {state.status === 'ready' && (
        <>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 14 }}>
            {state.avatarUrl ? (
              <Image source={{ uri: state.avatarUrl }} style={{ width: 52, height: 52, borderRadius: 26 }} />
            ) : (
              <View style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: colors.accentSoft, borderWidth: 1, borderColor: colors.accentGlow, alignItems: 'center', justifyContent: 'center' }}>
                <Text style={{ fontFamily: fonts.display, fontSize: 24 }}>{state.username.slice(0, 1).toUpperCase()}</Text>
              </View>
            )}
            <View>
              <Text variant="caption" muted>{greeting()}</Text>
              <Text variant="title">{state.username}</Text>
            </View>
          </View>

          {state.bikeCount === 0 ? (
            <GlassCard>
              <EmptyState
                icon={<Warehouse size={32} color={colors.accent} />}
                title="Garajın henüz boş"
                message="İlk motosikletini ekle; bakım, yakıt ve sürüş kayıtların burada görünsün."
                actionLabel="Garaja git"
                onAction={() => router.navigate('/(tabs)/garage')}
              />
            </GlassCard>
          ) : (
            <GlassCard>
              <Text variant="section">{state.bikeCount} motosiklet</Text>
              <Text muted>Motor kartı, kilometre ve sürüş özeti garaj aşamasında bağlanacak.</Text>
              <View style={{ height: 14 }} />
              <Button label="GARAJIMA GİT" onPress={() => router.navigate('/(tabs)/garage')} />
            </GlassCard>
          )}
        </>
      )}
    </Screen>
  );
}
