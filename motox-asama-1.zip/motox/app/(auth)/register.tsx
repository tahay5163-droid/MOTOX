import { useState } from 'react';
import { View } from 'react-native';
import { Link, useRouter } from 'expo-router';
import { MailCheck } from 'lucide-react-native';
import { useAuth } from '@/providers/AuthProvider';
import { supabase } from '@/lib/supabase';
import { fieldErrors, registerSchema } from '@/lib/validation';
import { friendlyError } from '@/lib/errors';
import { colors } from '@/theme/tokens';
import { Screen } from '@/components/ui/Screen';
import { Text } from '@/components/ui/Text';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { Wordmark } from '@/components/Wordmark';

export default function Register() {
  const { signUp } = useAuth();
  const router = useRouter();
  const [form, setForm] = useState({ username: '', email: '', password: '', confirm: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const [confirmSent, setConfirmSent] = useState(false);

  const set = (k: keyof typeof form) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  async function submit() {
    setFormError('');
    const parsed = registerSchema.safeParse(form);
    if (!parsed.success) return setErrors(fieldErrors(parsed.error));
    setErrors({});
    setBusy(true);
    try {
      const { data: free, error: rpcError } = await supabase.rpc('is_username_available', { p_username: parsed.data.username });
      if (rpcError) throw rpcError;
      if (!free) return setErrors({ username: 'Bu kullanıcı adı alınmış. Başka bir tane dene.' });

      const { needsEmailConfirm } = await signUp({
        email: parsed.data.email, password: parsed.data.password, username: parsed.data.username,
      });
      if (needsEmailConfirm) setConfirmSent(true);
      // Doğrulama kapalıysa oturum açılır, AuthGate yönlendirir.
    } catch (e) {
      setFormError(friendlyError(e));
    } finally {
      setBusy(false);
    }
  }

  if (confirmSent) {
    return (
      <Screen centered>
        <EmptyState
          icon={<MailCheck size={32} color={colors.accent} />}
          title="E-postanı doğrula"
          message={`${form.email} adresine bir doğrulama bağlantısı gönderdik. Bağlantıya dokunduktan sonra giriş yapabilirsin.`}
          actionLabel="Girişe dön"
          onAction={() => router.replace('/(auth)/login')}
        />
      </Screen>
    );
  }

  return (
    <Screen centered>
      <Wordmark size={44} />
      <View style={{ gap: 6 }}>
        <Text variant="title">Hesap oluştur</Text>
        <Text muted>Garajını kur, bakımlarını ve sürüşlerini takip et.</Text>
      </View>
      <View style={{ gap: 14 }}>
        <Input label="Kullanıcı adı" value={form.username} onChangeText={set('username')} error={errors.username}
          autoCapitalize="none" autoCorrect={false} autoComplete="username-new" />
        <Input label="E-posta" value={form.email} onChangeText={set('email')} error={errors.email}
          autoCapitalize="none" autoComplete="email" keyboardType="email-address" textContentType="emailAddress" />
        <Input label="Şifre" value={form.password} onChangeText={set('password')} error={errors.password}
          secureTextEntry autoComplete="password-new" textContentType="newPassword" />
        <Input label="Şifre (tekrar)" value={form.confirm} onChangeText={set('confirm')} error={errors.confirm}
          secureTextEntry autoComplete="password-new" onSubmitEditing={submit} returnKeyType="go" />
        {!!formError && <Text variant="caption" color={colors.danger}>{formError}</Text>}
      </View>
      <Button label="KAYIT OL" onPress={submit} loading={busy} />
      <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 6 }}>
        <Text muted>Zaten hesabın var mı?</Text>
        <Link href="/(auth)/login"><Text color={colors.accent} variant="bodyStrong">Giriş yap</Text></Link>
      </View>
    </Screen>
  );
}
