import { useState } from 'react';
import { View } from 'react-native';
import { Link } from 'expo-router';
import { useAuth } from '@/providers/AuthProvider';
import { fieldErrors, loginSchema } from '@/lib/validation';
import { friendlyError } from '@/lib/errors';
import { colors } from '@/theme/tokens';
import { Screen } from '@/components/ui/Screen';
import { Text } from '@/components/ui/Text';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { Wordmark } from '@/components/Wordmark';

export default function Login() {
  const { signIn } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit() {
    setFormError('');
    const parsed = loginSchema.safeParse({ email, password });
    if (!parsed.success) return setErrors(fieldErrors(parsed.error));
    setErrors({});
    setBusy(true);
    try {
      await signIn(parsed.data.email, parsed.data.password);
      // Yönlendirmeyi AuthGate yapar.
    } catch (e) {
      setFormError(friendlyError(e));
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen centered>
      <Wordmark size={44} />
      <View style={{ gap: 6 }}>
        <Text variant="title">Tekrar hoş geldin</Text>
        <Text muted>Garajına ve sürüşlerine kaldığın yerden devam et.</Text>
      </View>

      <View style={{ gap: 14 }}>
        <Input label="E-posta" value={email} onChangeText={setEmail} error={errors.email}
          autoCapitalize="none" autoComplete="email" keyboardType="email-address" textContentType="emailAddress" />
        <Input label="Şifre" value={password} onChangeText={setPassword} error={errors.password}
          secureTextEntry autoComplete="password" textContentType="password" onSubmitEditing={submit} returnKeyType="go" />
        {!!formError && <Text variant="caption" color={colors.danger}>{formError}</Text>}
        <Link href="/(auth)/forgot-password" style={{ alignSelf: 'flex-end' }}>
          <Text variant="caption" color={colors.accent}>Şifremi unuttum</Text>
        </Link>
      </View>

      <Button label="GİRİŞ YAP" onPress={submit} loading={busy} />

      <View style={{ flexDirection: 'row', justifyContent: 'center', gap: 6 }}>
        <Text muted>Hesabın yok mu?</Text>
        <Link href="/(auth)/register"><Text color={colors.accent} variant="bodyStrong">Kayıt ol</Text></Link>
      </View>
    </Screen>
  );
}
