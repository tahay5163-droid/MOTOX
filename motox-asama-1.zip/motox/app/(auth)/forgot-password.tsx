import { useState } from 'react';
import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { MailCheck } from 'lucide-react-native';
import { useAuth } from '@/providers/AuthProvider';
import { fieldErrors, forgotSchema } from '@/lib/validation';
import { friendlyError } from '@/lib/errors';
import { colors } from '@/theme/tokens';
import { Screen } from '@/components/ui/Screen';
import { Text } from '@/components/ui/Text';
import { Input } from '@/components/ui/Input';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';

export default function ForgotPassword() {
  const { resetPassword } = useAuth();
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);

  async function submit() {
    setError('');
    const parsed = forgotSchema.safeParse({ email });
    if (!parsed.success) return setError(fieldErrors(parsed.error).email ?? '');
    setBusy(true);
    try {
      await resetPassword(parsed.data.email);
      setSent(true);
    } catch (e) {
      setError(friendlyError(e));
    } finally {
      setBusy(false);
    }
  }

  if (sent) {
    return (
      <Screen centered>
        <EmptyState
          icon={<MailCheck size={32} color={colors.accent} />}
          title="Bağlantı yolda"
          message="Bu e-posta ile kayıtlı bir hesap varsa, şifre sıfırlama bağlantısı gelen kutuna gönderildi."
          actionLabel="Girişe dön"
          onAction={() => router.replace('/(auth)/login')}
        />
      </Screen>
    );
  }

  return (
    <Screen centered>
      <View style={{ gap: 6 }}>
        <Text variant="title">Şifreni sıfırla</Text>
        <Text muted>Hesabının e-postasını gir, sana sıfırlama bağlantısı gönderelim.</Text>
      </View>
      <Input label="E-posta" value={email} onChangeText={setEmail} error={error}
        autoCapitalize="none" autoComplete="email" keyboardType="email-address" onSubmitEditing={submit} returnKeyType="send" />
      <Button label="BAĞLANTI GÖNDER" onPress={submit} loading={busy} />
      <Button label="Geri dön" variant="ghost" onPress={() => router.back()} />
    </Screen>
  );
}
