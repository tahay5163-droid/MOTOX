import { useEffect, useState } from 'react';
import { View } from 'react-native';
import { useRouter } from 'expo-router';
import Animated, {
  Easing, useAnimatedStyle, useSharedValue, withDelay, withTiming,
} from 'react-native-reanimated';
import { useAuth } from '@/providers/AuthProvider';
import { colors, fonts } from '@/theme/tokens';
import { Text } from '@/components/ui/Text';

const MIN_SPLASH_MS = 2300;

export default function Splash() {
  const { session, loading } = useAuth();
  const router = useRouter();
  const [minElapsed, setMinElapsed] = useState(false);

  const word = useSharedValue(0);
  const bar = useSharedValue(0);
  const tag = useSharedValue(0);

  useEffect(() => {
    const ease = Easing.out(Easing.cubic);
    bar.value = withTiming(1, { duration: 650, easing: ease });
    word.value = withDelay(250, withTiming(1, { duration: 750, easing: ease }));
    tag.value = withDelay(1100, withTiming(1, { duration: 600 }));
    const t = setTimeout(() => setMinElapsed(true), MIN_SPLASH_MS);
    return () => clearTimeout(t);
  }, [bar, word, tag]);

  useEffect(() => {
    if (minElapsed && !loading) router.replace(session ? '/(tabs)' : '/(auth)/login');
  }, [minElapsed, loading, session, router]);

  const wordStyle = useAnimatedStyle(() => ({
    opacity: word.value,
    transform: [{ translateX: (1 - word.value) * -40 }, { skewX: '-10deg' }],
  }));
  const barStyle = useAnimatedStyle(() => ({
    transform: [{ scaleX: bar.value }, { skewX: '-30deg' }],
  }));
  const tagStyle = useAnimatedStyle(() => ({ opacity: tag.value }));

  return (
    <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' }}>
      <Animated.Text
        style={[{ color: colors.text, fontFamily: fonts.display, fontSize: 84, letterSpacing: 10 }, wordStyle]}
      >
        MOTOX
      </Animated.Text>
      <Animated.View
        style={[
          { height: 5, width: 230, backgroundColor: colors.accent, marginTop: 4, transformOrigin: 'left' as any,
            shadowColor: colors.accent, shadowOpacity: 0.9, shadowRadius: 14, shadowOffset: { width: 0, height: 0 } },
          barStyle,
        ]}
      />
      <Animated.View style={[{ marginTop: 22 }, tagStyle]}>
        <Text variant="caption" muted style={{ letterSpacing: 4 }}>YOUR RIDE. YOUR WORLD.</Text>
      </Animated.View>
    </View>
  );
}
