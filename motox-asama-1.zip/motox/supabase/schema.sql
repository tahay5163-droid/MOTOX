-- MOTOX veritabanı şeması + Row Level Security
-- Supabase > SQL Editor'e yapıştırıp çalıştır.

create extension if not exists pgcrypto;

-- ============ TABLOLAR ============
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null check (username ~ '^[a-zA-Z0-9_]{3,20}$'),
  full_name text,
  avatar_url text,
  bio text check (char_length(bio) <= 300),
  expo_push_token text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index profiles_username_lower_idx on public.profiles (lower(username));

create table public.user_settings (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  notify_maintenance boolean not null default true,
  notify_social boolean not null default true,
  notify_marketplace boolean not null default true,
  profile_private boolean not null default false,
  show_garage boolean not null default true
);

create table public.motorcycles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  brand text not null,
  model text not null,
  year int check (year between 1950 and 2100),
  engine_cc int check (engine_cc > 0),
  color text,
  plate text,                       -- özel: yalnızca sahibi görür
  odometer_km int not null default 0 check (odometer_km >= 0),
  photo_url text,
  purchase_date date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.motorcycles (user_id);

create table public.maintenance_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  motorcycle_id uuid not null references public.motorcycles(id) on delete cascade,
  category text not null check (category in (
    'engine_oil','oil_filter','air_filter','chain_cleaning','chain_lube',
    'chain_replacement','tire_replacement','brake_pads','battery_check','general_service')),
  performed_at date not null,
  odometer_km int not null check (odometer_km >= 0),
  cost numeric(10,2) not null default 0 check (cost >= 0),
  description text,
  next_due_km int,
  remind_at date,
  created_at timestamptz not null default now()
);
create index on public.maintenance_records (user_id, remind_at);
create index on public.maintenance_records (motorcycle_id, performed_at desc);

create table public.fuel_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  motorcycle_id uuid not null references public.motorcycles(id) on delete cascade,
  liters numeric(7,2) not null check (liters > 0),
  price_per_liter numeric(8,2) not null check (price_per_liter > 0),
  total_cost numeric(10,2) not null check (total_cost >= 0),
  odometer_km int not null check (odometer_km >= 0),
  filled_at date not null,
  created_at timestamptz not null default now()
);
create index on public.fuel_records (motorcycle_id, filled_at desc);

create table public.ride_records (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  motorcycle_id uuid references public.motorcycles(id) on delete set null,
  start_location text,
  end_location text,
  ridden_at timestamptz not null default now(),
  distance_km numeric(8,2) not null default 0 check (distance_km >= 0),
  duration_min int not null default 0 check (duration_min >= 0),
  avg_speed_kmh numeric(5,1),
  notes text,
  route jsonb,                      -- [{lat,lng,t}, ...]
  created_at timestamptz not null default now()
);
create index on public.ride_records (user_id, ridden_at desc);

create table public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text check (char_length(body) <= 2000),
  image_url text,
  created_at timestamptz not null default now(),
  check (body is not null or image_url is not null)
);
create index on public.posts (created_at desc);
create index on public.posts (user_id, created_at desc);

create table public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);
create index on public.comments (post_id, created_at);

create table public.likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  check (follower_id <> following_id)
);
create index on public.follows (following_id);

-- Şikâyet (topluluk özelliği için gerekli; istenen listeye ek tablo)
create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  post_id uuid references public.posts(id) on delete cascade,
  listing_id uuid,
  reason text not null check (char_length(reason) between 3 and 500),
  created_at timestamptz not null default now(),
  check (post_id is not null or listing_id is not null)
);

create table public.marketplace_listings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  category text not null check (category in
    ('motorcycle','helmet','jacket','gloves','accessory','spare_part')),
  title text not null check (char_length(title) between 3 and 120),
  description text check (char_length(description) <= 3000),
  price numeric(12,2) not null check (price >= 0),
  currency text not null default 'TRY',
  location text,
  contact_info text,
  image_urls text[] not null default '{}',
  status text not null default 'active' check (status in ('active','sold','removed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.marketplace_listings (category, status, created_at desc);

create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  type text not null,               -- like | comment | follow | maintenance | system
  title text not null,
  body text,
  data jsonb not null default '{}',
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index on public.notifications (user_id, created_at desc);

-- ============ updated_at ============
create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$ begin new.updated_at = now(); return new; end $$;

create trigger t_profiles_upd before update on public.profiles for each row execute function public.touch_updated_at();
create trigger t_motorcycles_upd before update on public.motorcycles for each row execute function public.touch_updated_at();
create trigger t_listings_upd before update on public.marketplace_listings for each row execute function public.touch_updated_at();

-- ============ Yeni kullanıcı -> profil + ayarlar ============
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare uname text;
begin
  uname := coalesce(nullif(new.raw_user_meta_data->>'username',''), 'rider_' || substr(new.id::text,1,8));
  begin
    insert into public.profiles (id, username) values (new.id, uname);
  exception when unique_violation or check_violation then
    insert into public.profiles (id, username) values (new.id, 'rider_' || substr(new.id::text,1,8));
  end;
  insert into public.user_settings (user_id) values (new.id);
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- ============ Bildirim tetikleyicileri ============
create or replace function public.notify_like() returns trigger
language plpgsql security definer set search_path = public as $$
declare owner uuid; uname text;
begin
  select user_id into owner from posts where id = new.post_id;
  if owner is not null and owner <> new.user_id then
    select username into uname from profiles where id = new.user_id;
    insert into notifications (user_id, type, title, body, data)
    values (owner, 'like', 'Yeni beğeni', uname || ' gönderini beğendi.',
            jsonb_build_object('post_id', new.post_id, 'actor_id', new.user_id));
  end if;
  return new;
end $$;
create trigger t_notify_like after insert on public.likes for each row execute function public.notify_like();

create or replace function public.notify_comment() returns trigger
language plpgsql security definer set search_path = public as $$
declare owner uuid; uname text;
begin
  select user_id into owner from posts where id = new.post_id;
  if owner is not null and owner <> new.user_id then
    select username into uname from profiles where id = new.user_id;
    insert into notifications (user_id, type, title, body, data)
    values (owner, 'comment', 'Yeni yorum', uname || ' gönderine yorum yaptı.',
            jsonb_build_object('post_id', new.post_id, 'actor_id', new.user_id));
  end if;
  return new;
end $$;
create trigger t_notify_comment after insert on public.comments for each row execute function public.notify_comment();

create or replace function public.notify_follow() returns trigger
language plpgsql security definer set search_path = public as $$
declare uname text;
begin
  select username into uname from profiles where id = new.follower_id;
  insert into notifications (user_id, type, title, body, data)
  values (new.following_id, 'follow', 'Yeni takipçi', uname || ' seni takip etmeye başladı.',
          jsonb_build_object('actor_id', new.follower_id));
  return new;
end $$;
create trigger t_notify_follow after insert on public.follows for each row execute function public.notify_follow();

-- ============ RPC ============
create or replace function public.is_username_available(p_username text) returns boolean
language sql security definer set search_path = public stable as $$
  select not exists (select 1 from profiles where lower(username) = lower(p_username));
$$;
grant execute on function public.is_username_available(text) to anon, authenticated;

create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  delete from auth.users where id = auth.uid();   -- tüm veriler cascade ile silinir
end $$;
revoke all on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- ============ ROW LEVEL SECURITY ============
alter table public.profiles enable row level security;
alter table public.user_settings enable row level security;
alter table public.motorcycles enable row level security;
alter table public.maintenance_records enable row level security;
alter table public.fuel_records enable row level security;
alter table public.ride_records enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.likes enable row level security;
alter table public.follows enable row level security;
alter table public.reports enable row level security;
alter table public.marketplace_listings enable row level security;
alter table public.notifications enable row level security;

-- profiles: giriş yapmış herkes görür, sadece sahibi düzenler
create policy profiles_read on public.profiles for select to authenticated using (true);
create policy profiles_update on public.profiles for update to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));

create policy settings_all on public.user_settings for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- Tamamen özel tablolar: sadece sahibi
create policy moto_own on public.motorcycles for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

create policy maint_own on public.maintenance_records for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid())
    and exists (select 1 from public.motorcycles m where m.id = motorcycle_id and m.user_id = (select auth.uid())));

create policy fuel_own on public.fuel_records for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid())
    and exists (select 1 from public.motorcycles m where m.id = motorcycle_id and m.user_id = (select auth.uid())));

create policy ride_own on public.ride_records for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));

-- Topluluk
create policy posts_read on public.posts for select to authenticated using (true);
create policy posts_insert on public.posts for insert to authenticated with check (user_id = (select auth.uid()));
create policy posts_delete on public.posts for delete to authenticated using (user_id = (select auth.uid()));

create policy comments_read on public.comments for select to authenticated using (true);
create policy comments_insert on public.comments for insert to authenticated with check (user_id = (select auth.uid()));
create policy comments_delete on public.comments for delete to authenticated using (
  user_id = (select auth.uid())
  or exists (select 1 from public.posts p where p.id = post_id and p.user_id = (select auth.uid())));

create policy likes_read on public.likes for select to authenticated using (true);
create policy likes_insert on public.likes for insert to authenticated with check (user_id = (select auth.uid()));
create policy likes_delete on public.likes for delete to authenticated using (user_id = (select auth.uid()));

create policy follows_read on public.follows for select to authenticated using (true);
create policy follows_insert on public.follows for insert to authenticated with check (follower_id = (select auth.uid()));
create policy follows_delete on public.follows for delete to authenticated using (follower_id = (select auth.uid()));

create policy reports_insert on public.reports for insert to authenticated with check (reporter_id = (select auth.uid()));
create policy reports_read_own on public.reports for select to authenticated using (reporter_id = (select auth.uid()));

-- Pazar
create policy listings_read on public.marketplace_listings for select to authenticated
  using (status = 'active' or user_id = (select auth.uid()));
create policy listings_insert on public.marketplace_listings for insert to authenticated with check (user_id = (select auth.uid()));
create policy listings_update on public.marketplace_listings for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy listings_delete on public.marketplace_listings for delete to authenticated using (user_id = (select auth.uid()));

-- Bildirimler: ekleme sadece tetikleyiciler (security definer) ile
create policy notif_read on public.notifications for select to authenticated using (user_id = (select auth.uid()));
create policy notif_update on public.notifications for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
create policy notif_delete on public.notifications for delete to authenticated using (user_id = (select auth.uid()));

-- ============ STORAGE ============
insert into storage.buckets (id, name, public) values
  ('avatars','avatars',true), ('motorcycles','motorcycles',true),
  ('posts','posts',true), ('listings','listings',true)
on conflict (id) do nothing;

create policy media_read on storage.objects for select
  using (bucket_id in ('avatars','motorcycles','posts','listings'));
create policy media_insert on storage.objects for insert to authenticated
  with check (bucket_id in ('avatars','motorcycles','posts','listings')
    and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy media_update on storage.objects for update to authenticated
  using (bucket_id in ('avatars','motorcycles','posts','listings')
    and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy media_delete on storage.objects for delete to authenticated
  using (bucket_id in ('avatars','motorcycles','posts','listings')
    and (storage.foldername(name))[1] = (select auth.uid())::text);
