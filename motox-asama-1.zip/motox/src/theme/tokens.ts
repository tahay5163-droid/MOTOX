export const colors = {
  bg: '#08090C',
  card: '#14161B',
  card2: '#1D2027',
  accent: '#E50924',
  accentSoft: 'rgba(229,9,36,0.14)',
  accentGlow: 'rgba(229,9,36,0.35)',
  text: '#FFFFFF',
  textMuted: '#9AA0AB',
  textDim: '#5F6570',
  border: 'rgba(255,255,255,0.07)',
  borderStrong: 'rgba(255,255,255,0.14)',
  glass: 'rgba(29,32,39,0.55)',
  success: '#2BC48A',
  warning: '#F5A524',
  danger: '#FF4D5E',
} as const;

export const spacing = { xs: 4, sm: 8, md: 12, lg: 20, xl: 28, xxl: 40 } as const;
export const radius = { sm: 10, md: 16, lg: 22, xl: 30, pill: 999 } as const;

// Barlow Condensed: başlık/rakam (sportif), Barlow: gövde metni
export const fonts = {
  display: 'BarlowCondensed_800ExtraBold',
  heading: 'BarlowCondensed_700Bold',
  body: 'Barlow_400Regular',
  bodyMedium: 'Barlow_500Medium',
  bodySemi: 'Barlow_600SemiBold',
} as const;

export const type = {
  hero: { fontFamily: fonts.display, fontSize: 44, lineHeight: 46, letterSpacing: 0.5 },
  title: { fontFamily: fonts.heading, fontSize: 28, lineHeight: 32, letterSpacing: 0.3 },
  section: { fontFamily: fonts.heading, fontSize: 20, lineHeight: 24, letterSpacing: 0.3 },
  body: { fontFamily: fonts.body, fontSize: 16, lineHeight: 23 },
  bodyStrong: { fontFamily: fonts.bodySemi, fontSize: 16, lineHeight: 23 },
  caption: { fontFamily: fonts.bodyMedium, fontSize: 13, lineHeight: 18 },
} as const;
