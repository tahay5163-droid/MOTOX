import type { ReactNode } from 'react';
import { View } from 'react-native';
import { colors, radius } from '@/theme/tokens';
import { Text } from './Text';
import { Button } from './Button';

type Props = {
  icon: ReactNode;
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
};

export function EmptyState({ icon, title, message, actionLabel, onAction }: Props) {
  return (
    <View style={{ alignItems: 'center', gap: 12, paddingVertical: 28, paddingHorizontal: 12 }}>
      <View
        style={{
          width: 72, height: 72, borderRadius: radius.xl, alignItems: 'center', justifyContent: 'center',
          backgroundColor: colors.accentSoft, borderWidth: 1, borderColor: colors.accentGlow,
        }}
      >
        {icon}
      </View>
      <Text variant="section" style={{ textAlign: 'center' }}>{title}</Text>
      <Text muted style={{ textAlign: 'center', maxWidth: 300 }}>{message}</Text>
      {actionLabel && onAction && <Button label={actionLabel} onPress={onAction} style={{ marginTop: 8, alignSelf: 'stretch' }} />}
    </View>
  );
}
