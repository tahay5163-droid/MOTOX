import type { ReactNode } from 'react';
import { KeyboardAvoidingView, Platform, ScrollView, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, spacing } from '@/theme/tokens';

type Props = { children: ReactNode; tabBar?: boolean; centered?: boolean };

/** Güvenli alan + klavye + kaydırma sarmalayıcısı. Her ekran bunu kullanır. */
export function Screen({ children, tabBar = false, centered = false }: Props) {
  const insets = useSafeAreaInsets();
  return (
    <View style={{ flex: 1, backgroundColor: colors.bg }}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="interactive"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            flexGrow: 1,
            justifyContent: centered ? 'center' : 'flex-start',
            paddingTop: insets.top + spacing.lg,
            paddingBottom: (tabBar ? 120 : spacing.xl) + insets.bottom,
            paddingHorizontal: spacing.lg,
            gap: spacing.lg,
          }}
        >
          {children}
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}
