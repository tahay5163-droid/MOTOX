import { useEffect } from 'react';
import type { DimensionValue, ViewStyle } from 'react-native';
import Animated, { useAnimatedStyle, useSharedValue, withRepeat, withSequence, withTiming } from 'react-native-reanimated';
import { colors, radius } from '@/theme/tokens';

export function Skeleton({ width = '100%', height = 16, style }: { width?: DimensionValue; height?: number; style?: ViewStyle }) {
  const o = useSharedValue(0.45);
  useEffect(() => {
    o.value = withRepeat(withSequence(withTiming(0.9, { duration: 800 }), withTiming(0.45, { duration: 800 })), -1);
  }, [o]);
  const anim = useAnimatedStyle(() => ({ opacity: o.value }));
  return <Animated.View style={[{ width, height, backgroundColor: colors.card2, borderRadius: radius.sm }, anim, style]} />;
}
