import { Text as RNText, type TextProps } from 'react-native';
import { colors, type as t } from '@/theme/tokens';

type Variant = keyof typeof t;
type Props = TextProps & { variant?: Variant; muted?: boolean; color?: string };

export function Text({ variant = 'body', muted, color, style, ...rest }: Props) {
  return (
    <RNText
      {...rest}
      style={[t[variant], { color: color ?? (muted ? colors.textMuted : colors.text) }, style]}
    />
  );
}
