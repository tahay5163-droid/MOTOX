import { forwardRef, useState } from 'react';
import { Pressable, StyleSheet, TextInput, View, type TextInputProps } from 'react-native';
import { Eye, EyeOff } from 'lucide-react-native';
import { colors, fonts, radius } from '@/theme/tokens';
import { Text } from './Text';

type Props = TextInputProps & { label: string; error?: string };

export const Input = forwardRef<TextInput, Props>(function Input({ label, error, secureTextEntry, ...rest }, ref) {
  const [focused, setFocused] = useState(false);
  const [hidden, setHidden] = useState(true);
  const isSecret = !!secureTextEntry;

  return (
    <View style={{ gap: 6 }}>
      <Text variant="caption" muted>{label}</Text>
      <View
        style={[
          styles.field,
          focused && { borderColor: colors.accent },
          !!error && { borderColor: colors.danger },
        ]}
      >
        <TextInput
          ref={ref}
          {...rest}
          secureTextEntry={isSecret && hidden}
          onFocus={(e) => { setFocused(true); rest.onFocus?.(e); }}
          onBlur={(e) => { setFocused(false); rest.onBlur?.(e); }}
          placeholderTextColor={colors.textDim}
          selectionColor={colors.accent}
          style={styles.input}
        />
        {isSecret && (
          <Pressable
            hitSlop={12}
            accessibilityLabel={hidden ? 'Şifreyi göster' : 'Şifreyi gizle'}
            onPress={() => setHidden((h) => !h)}
          >
            {hidden ? <EyeOff size={20} color={colors.textMuted} /> : <Eye size={20} color={colors.textMuted} />}
          </Pressable>
        )}
      </View>
      {!!error && <Text variant="caption" color={colors.danger}>{error}</Text>}
    </View>
  );
});

const styles = StyleSheet.create({
  field: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.md,
    paddingHorizontal: 16,
    height: 54,
  },
  input: { flex: 1, color: colors.text, fontFamily: fonts.body, fontSize: 16, height: '100%' },
});
