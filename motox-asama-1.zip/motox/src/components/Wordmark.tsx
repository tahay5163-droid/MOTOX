import { View } from 'react-native';
import { colors, fonts } from '@/theme/tokens';
import { Text } from './ui/Text';

export function Wordmark({ size = 40 }: { size?: number }) {
  return (
    <View style={{ alignItems: 'flex-start' }}>
      <Text
        style={{
          fontFamily: fonts.display,
          fontSize: size,
          lineHeight: size * 1.05,
          letterSpacing: size * 0.12,
          transform: [{ skewX: '-10deg' }],
        }}
      >
        MOTOX
      </Text>
      <View style={{ height: Math.max(3, size / 14), width: size * 1.6, backgroundColor: colors.accent, marginTop: 2, transform: [{ skewX: '-30deg' }] }} />
    </View>
  );
}
