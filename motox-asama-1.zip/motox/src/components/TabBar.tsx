import { useEffect, useState } from 'react';
import { LayoutChangeEvent, Pressable, StyleSheet, View } from 'react-native';
import type { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import { BlurView } from 'expo-blur';
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { House, Route, User, Users, Warehouse, type LucideIcon } from 'lucide-react-native';
import { colors, fonts, radius } from '@/theme/tokens';

const META: Record<string, { label: string; Icon: LucideIcon }> = {
  index: { label: 'Ana Sayfa', Icon: House },
  garage: { label: 'Garaj', Icon: Warehouse },
  ride: { label: 'Sürüş', Icon: Route },
  community: { label: 'Topluluk', Icon: Users },
  profile: { label: 'Profil', Icon: User },
};

export function TabBar({ state, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();
  const [width, setWidth] = useState(0);
  const x = useSharedValue(0);
  const tabW = width / state.routes.length;

  useEffect(() => {
    if (tabW) x.value = withSpring(state.index * tabW, { damping: 20, stiffness: 220 });
  }, [state.index, tabW, x]);

  const pill = useAnimatedStyle(() => ({ transform: [{ translateX: x.value }] }));
  const onLayout = (e: LayoutChangeEvent) => setWidth(e.nativeEvent.layout.width);

  return (
    <View style={[styles.outer, { bottom: Math.max(insets.bottom, 12) }]} pointerEvents="box-none">
      <View style={styles.bar}>
        <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
        <View style={styles.row} onLayout={onLayout}>
          {!!tabW && (
            <Animated.View style={[styles.pillWrap, { width: tabW }, pill]}>
              <View style={styles.pill} />
            </Animated.View>
          )}
          {state.routes.map((route, i) => {
            const focused = state.index === i;
            const meta = META[route.name];
            if (!meta) return null;
            const { Icon, label } = meta;
            return (
              <Pressable
                key={route.key}
                accessibilityRole="tab"
                accessibilityLabel={label}
                accessibilityState={{ selected: focused }}
                onPress={() => {
                  const e = navigation.emit({ type: 'tabPress', target: route.key, canPreventDefault: true });
                  if (!focused && !e.defaultPrevented) navigation.navigate(route.name);
                }}
                style={styles.tab}
              >
                <Icon size={22} color={focused ? colors.text : colors.textMuted} strokeWidth={focused ? 2.4 : 1.8} />
                <Animated.Text
                  style={{ fontFamily: fonts.bodySemi, fontSize: 11, color: focused ? colors.text : colors.textMuted }}
                  numberOfLines={1}
                >
                  {label}
                </Animated.Text>
              </Pressable>
            );
          })}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  outer: { position: 'absolute', left: 14, right: 14 },
  bar: {
    height: 68, borderRadius: radius.xl, overflow: 'hidden',
    backgroundColor: 'rgba(20,22,27,0.82)', borderWidth: 1, borderColor: colors.borderStrong,
  },
  row: { flex: 1, flexDirection: 'row', alignItems: 'center' },
  tab: { flex: 1, height: '100%', alignItems: 'center', justifyContent: 'center', gap: 3 },
  pillWrap: { position: 'absolute', top: 0, bottom: 0, left: 0, alignItems: 'center', justifyContent: 'center' },
  pill: {
    width: '84%', height: '78%', borderRadius: radius.lg, backgroundColor: colors.accent,
    shadowColor: colors.accent, shadowOpacity: 0.55, shadowRadius: 14, shadowOffset: { width: 0, height: 4 }, elevation: 6,
  },
});
