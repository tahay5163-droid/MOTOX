export function friendlyError(e: unknown): string {
  const msg = (e instanceof Error ? e.message : typeof e === 'string' ? e : (e as any)?.message ?? '').toLowerCase();
  if (msg.includes('invalid login credentials')) return 'E-posta veya şifre hatalı.';
  if (msg.includes('email not confirmed')) return 'E-posta adresin henüz doğrulanmadı. Gelen kutunu kontrol et.';
  if (msg.includes('already registered') || msg.includes('already been registered'))
    return 'Bu e-posta ile zaten bir hesap var. Giriş yapmayı dene.';
  if (msg.includes('rate limit') || msg.includes('too many'))
    return 'Çok fazla deneme yaptın. Birkaç dakika sonra tekrar dene.';
  if (msg.includes('network') || msg.includes('fetch'))
    return 'Bağlantı kurulamadı. İnternet bağlantını kontrol edip tekrar dene.';
  if (msg.includes('password')) return 'Şifre en az 8 karakter olmalı.';
  return 'Bir sorun oluştu. Lütfen tekrar dene.';
}
