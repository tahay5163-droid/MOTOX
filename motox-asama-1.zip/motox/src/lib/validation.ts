import { z } from 'zod';

export const emailSchema = z.string().trim().toLowerCase().email('Geçerli bir e-posta adresi gir.');

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, 'Şifreni gir.'),
});

export const registerSchema = z
  .object({
    username: z
      .string()
      .trim()
      .regex(/^[a-zA-Z0-9_]{3,20}$/, 'Kullanıcı adı 3-20 karakter olmalı; harf, rakam ve alt çizgi içerebilir.'),
    email: emailSchema,
    password: z
      .string()
      .min(8, 'Şifre en az 8 karakter olmalı.')
      .regex(/[A-Za-z]/, 'Şifre en az bir harf içermeli.')
      .regex(/[0-9]/, 'Şifre en az bir rakam içermeli.'),
    confirm: z.string(),
  })
  .refine((v) => v.password === v.confirm, { path: ['confirm'], message: 'Şifreler eşleşmiyor.' });

export const forgotSchema = z.object({ email: emailSchema });

/** zod hatalarını { alanAdı: mesaj } biçimine çevirir */
export function fieldErrors(error: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? '_');
    if (!out[key]) out[key] = issue.message;
  }
  return out;
}
